// $Header: /cvs/ieview/ieview/install.js,v 1.11 2004/10/28 14:18:21 roub Exp $

const APP_DISPLAY_NAME    = "IE View";
const APP_NAME            = "ieview";
const APP_PACKAGE         = "/Paul Roub/ieview";
const APP_VERSION         = "0.84";

const APP_JAR_FILE        = "ieview.jar";
const APP_CONTENT_FOLDER  = "content/";
const APP_LOCALE          = "en-US";
const APP_LOCALE_FOLDER   = "locale/" + APP_LOCALE + "/ieview/";

const APP_SUCCESS_MESSAGE = "New menuitems will appear on the link and page context menus.\n\n";

var chromef, chromeFlag;

initInstall(APP_NAME, APP_PACKAGE, APP_VERSION);

chromef = getFolder("Profile", "chrome");
chromeFlag = PROFILE_CHROME;

setPackageFolder(chromef);
var err = addFile("Paul Roub", APP_VERSION, "chrome/" + APP_JAR_FILE, chromef, null);

if (err == SUCCESS) 
{ 
	var jar = getFolder(chromef, APP_JAR_FILE);

	registerChrome(CONTENT | chromeFlag, jar, APP_CONTENT_FOLDER);
   registerChrome(LOCALE  | chromeFlag, jar, APP_LOCALE_FOLDER);

	err = performInstall();

	if(err == SUCCESS || error == 999) 
   {
		alert(APP_NAME + " " + APP_VERSION + " has been succesfully installed.\n"
			+APP_SUCCESS_MESSAGE
			+"Please restart your browser before continuing.");
	} 
   else 
   { 
		alert("Install failed. Error code:" + err);
		cancelInstall(err);
	}
} 
else 
{
	alert("Failed to create " +APP_JAR_FILE +"\n"
		+"You probably don't have appropriate permissions \n"
		+"(write access to phoenix/chrome directory). \n");
	cancelInstall(err);
}

