pref("tongwentang.autoconvert.chineseCharset", "off");
pref("tongwentang.autoconvert.oppositeCharsetOnly", "off");
pref("tongwentang.autoconvert.chineseEncodingOnly", true);
pref("tongwentang.debug", "off");
