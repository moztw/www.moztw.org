Installation Instructions:

This is Version 2.3.9 of the Attachment Mod.

The File Attachment Mod only supports phpBB 2.0.6.
The File Attachment Mod does not support *Nuke Portals.

Please read the Attachment Mod User Guide (docs/user_guide.html) to get familiar with the Attachment Mod.

For Installation Instructions, please read docs/install.txt.
If you want to update, you do not need to read docs/install.txt, instead read
the Documents at docs/update.

Upgrading Instructions:

Please read the Instructions in docs/update if you want to update.

If you want to upgrade from Version 2.3.8,
please read: docs/update/update_23x_to_latest.txt

If you want to update from versions prior to 2.3.0, please go
to http://www.opentools.de and open a new topic within the Attachment Mod.
The old update instructions are purged from this Archive.

---

Some Informations on the contrib and scripts directory.

For Informations what is placed into the contrib directory, please read: contrib/readme.txt

In the scripts directory you will find several needed update and install/uninstall scripts.
All these 'scripts' have to be uploaded to the phpBB2 Root Directory in order to work.
For additional Informations what is placed into the scripts directory, please read: scripts/readme.txt
