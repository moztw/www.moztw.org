The provided Files/Directories are:

- phpbb_attach
	Pre-edited phpBB 2.0.6 Files for the Attachment Mod. Use them to see if you
	have done any errors in editing the files or use them directly.
	Even if you use this files, read and follow the Installation Instructions in install.txt
	These Files only replace the Step Number III from the install.txt file.

- app_icons
	Here you will find several icons for several file types.
	Just upload them to your images directory. Please read the User Guide if
	you do not know how to use icons for presenting attachment data or how to
	setup images for Extension Groups.

	Thanks goes to stitch626 for providing this images. :)

- misc/download_secure.php - no longer there, please have a look at the original download.php file
	It is intended to stop leeching your files from other sites.

- styles
	Here you will find some viewtopic_attach_body.tpl files.
	Since this file is responsible for the look of Attachments, many users edit this file to their
	needs. Have a look at the Templating Section within the User Guide too.

	At the moment, there is a style for the fiapple template and an old-fashion style you know
	from the 2.2.x series of the Attachment Mod.
