<?php

//
// Create Thumbnails from all Attachments
// $Id: create_thumbnails.php,v 1.5 2003/06/18 17:53:01 acydburn Exp $
//

error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

define('IN_PHPBB', true);

$phpbb_root_path = './';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);	

if ( (!defined('ATTACH_VERSION')) || ( (!strstr(ATTACH_VERSION, '2.3.')) ) )
{
	message_die(GENERAL_MESSAGE, 'Only Version 2.3.x supported.');
}

$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);

if ( ($userdata['user_level'] != ADMIN) || (!$userdata['session_logged_in']) )
{
	message_die(GENERAL_MESSAGE, 'You are not authorized to execute this script, sorry, only the Administrator is allowed to do so.');
}

//
// BEGIN Functions

// END Functions
//

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--

font,th,td,p,body { font-family: "Courier New", courier; font-size: 11pt }

a:link,a:active,a:visited { color : #006699; }
a:hover		{ text-decoration: underline; color : #DD6900;}

hr	{ height: 0px; border: solid #D1D7DC 0px; border-top-width: 1px;}

.maintitle,h1,h2	{font-weight: bold; font-size: 22px; font-family: "Trebuchet MS",Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000000;}

.ok {color:green}

/* Import the fancy styles for IE only (NS4.x doesn't use the @import function) */
@import url("templates/subSilver/formIE.css"); 
-->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#006699" vlink="#5584AA">

<table width="100%" border="0" cellspacing="0" cellpadding="10" align="center"> 
	<tr>
		<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td><img src="templates/subSilver/images/logo_phpBB.gif" border="0" alt="Forum Home" vspace="1" /></td>
				<td align="center" width="100%" valign="middle"><span class="maintitle">Create Thumbnails</span></td>
			</tr>
		</table></td>
	</tr>
</table>

<br clear="all" />

<?php

$migrate_auto = ( isset($HTTP_GET_VARS['migrate_auto']) ) ? TRUE : FALSE;
$migrate_manual = ( isset($HTTP_GET_VARS['migrate_manual']) ) ? TRUE : FALSE;
$create_thumbnail = ( isset($HTTP_GET_VARS['create_thumbnail']) ) ? TRUE : FALSE;

if ($create_thumbnail)
{
	$attach_id = intval($HTTP_GET_VARS['create_thumbnail']);
}

$sql = "SELECT COUNT(*) as total FROM " . ATTACHMENTS_DESC_TABLE . "
	WHERE (thumbnail = 0) AND (mimetype LIKE '%image%')
	LIMIT 100";

if ( !($result = $db->sql_query($sql)) )
{
	$sql_error = $db->sql_error();
	print 'Could not query attachment informations - SQL ERROR:<br />';
	print $sql_error['code'] . ": ". $sql_error['message']. "<br>\n";
	die('Executed SQL Statement: <br />' . $sql);
}

$row = $db->sql_fetchrow($result);
$total = intval($row['total']);

if ($total == 0)
{
	die ('Nothing to convert here');
}

if ( (!is_imagick()) && (count(get_supported_image_types()) == 0) )
{
	die ('Unable to create thumbnails. This Server has no imagick installed and no GD Extensions Installed.');
}

//
// Let the User choose whether to review all Attachments or to do the convert automatically
//
if ( (!$migrate_auto) && (!$migrate_manual) )
{
	echo "<br />There are <b>" . $total . "</b> potential Attachments to create Thumbnails from.<br />";
	echo 'Do you want to try creating Thumnails from them automatically, please click this link: <a href="create_thumbnails.php?migrate_auto=1">Automatic Thumbnail Creation</a><br />';
	echo 'Do you want to try creating Thumnails from them manually (you will see the Attachment and then you are able to choose to create a Thumbnail from it or not), please click this link: <a href="create_thumbnails.php?migrate_manual=1">Manual Thumbnail Creation</a><br />';
}

if ( ($migrate_manual) && ($create_thumbnail) )
{
	$update_ids = array();

	$sql = "SELECT * FROM " . ATTACHMENTS_DESC_TABLE . "
	WHERE attach_id = " . $attach_id;

	if ( !($result = $db->sql_query($sql)) )
	{
		$sql_error = $db->sql_error();
		print 'Could not query attachment informations - SQL ERROR:<br />';
		print $sql_error['code'] . ": ". $sql_error['message']. "<br>\n";
		die('Executed SQL Statement: <br />' . $sql);
	}

	$row = $db->sql_fetchrow($result);

	if (intval($attach_config['allow_ftp_upload']))
	{
		$dest_file = THUMB_DIR . '/t_' . $row['physical_filename'];
	}
	else
	{
		$dest_file = $upload_dir . '/' . THUMB_DIR . '/t_' . $row['physical_filename'];
	}

	$source = $upload_dir . '/' . $row['physical_filename'];

	if (create_thumbnail($source, $dest_file, $row['mimetype']))
	{
		$update_ids[] = $row['attach_id'];
	}

	if (count($update_ids) > 0)
	{
		$sql = "UPDATE " . ATTACHMENTS_DESC_TABLE . " SET thumbnail = 1 WHERE attach_id IN (" . implode(', ', $update_ids) . ")";

		if ( !($result = $db->sql_query($sql)) )
		{
			$sql_error = $db->sql_error();
			print 'Could not query attachment informations - SQL ERROR:<br />';
			print $sql_error['code'] . ": ". $sql_error['message']. "<br>\n";
			die('Executed SQL Statement: <br />' . $sql);
		}
	}
}

if ( ($migrate_manual) || ($migrate_auto) )
{
	$sql = "SELECT * FROM " . ATTACHMENTS_DESC_TABLE . "
	WHERE (thumbnail = 0) AND (mimetype LIKE '%image%')
	LIMIT 100";

	if ( !($result = $db->sql_query($sql)) )
	{
		$sql_error = $db->sql_error();
		print 'Could not query attachment informations - SQL ERROR:<br />';
		print $sql_error['code'] . ": ". $sql_error['message']. "<br>\n";
		die('Executed SQL Statement: <br />' . $sql);
	}

	$update_ids = array();

	if ($db->sql_numrows($result) == 0)
	{
		die('Nothing more to convert.');
	}

	while ($row = $db->sql_fetchrow($result))
	{
		if (intval($attach_config['allow_ftp_upload']))
		{
			$dest_file = THUMB_DIR . '/t_' . $row['physical_filename'];
		}
		else
		{
			$dest_file = $upload_dir . '/' . THUMB_DIR . '/t_' . $row['physical_filename'];
		}

		if ( ($migrate_manual) )
		{
			echo '<br /><a href="download.php?id=' . $row['attach_id'] . '" target="_blank">Review the Attachment: ' . $row['real_filename'] . '</a>&nbsp; -- &nbsp;<a href="create_thumbnails.php?migrate_manual=1&create_thumbnail=' . $row['attach_id'] . '">Create Thumbnail</a><br />';
		}
		else if ( $migrate_auto )
		{
			$source = $upload_dir . '/' . $row['physical_filename'];

			if (create_thumbnail($source, $dest_file, $row['mimetype']))
			{
				echo "<br />Created Thumbnail from: " . $row['real_filename'];
				$update_ids[] = $row['attach_id'];
			}
		}
	}

	if (count($update_ids) > 0)
	{
		$sql = "UPDATE " . ATTACHMENTS_DESC_TABLE . " SET thumbnail = 1 WHERE attach_id IN (" . implode(', ', $update_ids) . ")";

		if ( !($result = $db->sql_query($sql)) )
		{
			$sql_error = $db->sql_error();
			print 'Could not query attachment informations - SQL ERROR:<br />';
			print $sql_error['code'] . ": ". $sql_error['message']. "<br>\n";
			die('Executed SQL Statement: <br />' . $sql);
		}
	}

	if ($total > 100)
	{
		echo "<br /><br />Now 100 from " . $total . " Thumbnails are created. Please hit the refresh button to create the next 100 thumbnails.<br />";
	}
	else
	{
		echo "<br /><br />FINISHED.<br />";
	}
}

?>