<?php
/***************************************************************************
 *                            mod_table_uninst.php
 *                            -------------------
 *   begin                : Monday, Jan 21, 2002
 *   copyright            : (C) 2002 Meik Sievertsen
 *   email                : acyd.burn@gmx.de
 *
 *   $Id: mod_table_uninst.php,v 1.5 2002/11/19 19:08:06 acydburn Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
define('ATTACH_INSTALL', true);

$phpbb_root_path='./';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);	
	
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);

if ( (!isset($dbms)) || ($dbms == 'oracle') || ($dbms == 'msaccess') )
{
	message_die(GENERAL_ERROR, "This Mod does not support Oracle and MsAccess Databases.");
}
else if( isset($dbms) )
{
	include($phpbb_root_path.'includes/db.'.$phpEx);
}

//
// Here we go
//
include($phpbb_root_path.'includes/sql_parse.'.$phpEx);

$available_dbms = array(
	"mysql" => array(
		"SCHEMA" => "mysql", 
		"DELIM" => ";",
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_remarks"
	), 
	"mysql4" => array(
		"SCHEMA" => "mysql", 
		"DELIM" => ";", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_remarks"
	), 
	"postgres" => array(
		"SCHEMA" => "postgres", 
		"DELIM" => ";", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	), 
	"mssql" => array(
		"SCHEMA" => "mssql", 
		"DELIM" => "GO", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	),
	"mssql-odbc" =>	array(
		"SCHEMA" => "mssql", 
		"DELIM" => "GO",
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	)
);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--

font,th,td,p,body { font-family: "Courier New", courier; font-size: 11pt }

a:link,a:active,a:visited { color : #006699; }
a:hover		{ text-decoration: underline; color : #DD6900;}

hr	{ height: 0px; border: solid #D1D7DC 0px; border-top-width: 1px;}

.maintitle,h1,h2	{font-weight: bold; font-size: 22px; font-family: "Trebuchet MS",Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000000;}

.ok {color:green}

/* Import the fancy styles for IE only (NS4.x doesn't use the @import function) */
@import url("templates/subSilver/formIE.css"); 
-->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#006699" vlink="#5584AA">

<table width="100%" border="0" cellspacing="0" cellpadding="10" align="center"> 
	<tr>
		<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td><img src="templates/subSilver/images/logo_phpBB.gif" border="0" alt="Forum Home" vspace="1" /></td>
				<td align="center" width="100%" valign="middle"><span class="maintitle">Uninstalling Attachment Mod</span></td>
			</tr>
		</table></td>
	</tr>
</table>

<br clear="all" />

<?php

$remove_remarks = $available_dbms[$dbms]['COMMENTS'];;
$delimiter = $available_dbms[$dbms]['DELIM']; 
$delimiter_basic = $available_dbms[$dbms]['DELIM_BASIC']; 

function row_in_shema($table, $key)
{
	global $db;

	$sql = "SELECT " . $key . " FROM " . $table;

	$result = $db->sql_query($sql);

	if ($result)
	{
		return (TRUE);
	}
	else
	{
		return (FALSE);
	}
}

function evaluate_statement($sql_query)
{
	global $table_prefix, $remove_remarks, $delimiter, $db;
	
	$sql_query = preg_replace('/phpbb_/', $table_prefix, $sql_query);

	$sql_query = $remove_remarks($sql_query);
	$sql_query = split_sql_file($sql_query, $delimiter);

	$sql_count = count($sql_query);

	for($i = 0; $i < $sql_count; $i++)
	{
		echo "Running :: " . $sql_query[$i];
		flush();

		if ( !($result = $db->sql_query($sql_query[$i])) )
		{
			$errored = true;
			$error = $db->sql_error();
			echo " -> <b>FAILED</b> ---> <u>" . $error['message'] . "</u><br /><br />\n\n";
		}
		else
		{
			echo " -> <b><span class=\"ok\">COMPLETED</span></b><br /><br />\n\n";
		}
	}
}

//
// drop table schema
//
$sql_array = array();

$sql_array['drop_schema'][] = "DROP TABLE phpbb_attachments_config";
$sql_array['drop_schema'][] = "DROP TABLE phpbb_forbidden_extensions";
$sql_array['drop_schema'][] = "DROP TABLE phpbb_extension_groups";
$sql_array['drop_schema'][] = "DROP TABLE phpbb_extensions";
$sql_array['drop_schema'][] = "DROP TABLE phpbb_attachments_desc";
$sql_array['drop_schema'][] = "DROP TABLE phpbb_attachments";
$sql_array['drop_schema'][] = "DROP TABLE phpbb_quota_limits";
$sql_array['drop_schema'][] = "DROP TABLE phpbb_attach_quota";

//
// build sql query
//
$sql_query = preg_replace('/phpbb_/', $table_prefix, $sql_array['drop_schema']);
$sql_count = count($sql_query);

echo "<html>\n";
echo "<body>\n";
for($i = 0; $i < $sql_count; $i++)
{
	echo "Running :: " . $sql_query[$i];
	flush();

	if ( !($result = $db->sql_query($sql_query[$i])) )
	{
		$errored = true;
		$error = $db->sql_error();
		echo " -> <b>FAILED</b> ---> <u>" . $error['message'] . "</u><br /><br />\n\n";
	}
	else
	{
		echo " -> <b><span class=\"ok\">COMPLETED</span></b><br /><br />\n\n";
	}
}

//
// Delete the download permissions and Attachment Indicators
//
if (row_in_shema(FORUMS_TABLE, 'auth_download'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") || ($dbms == 'msaccess') )
	{
		$sql_query = "ALTER TABLE phpbb_forums DROP auth_download;";
		evaluate_statement($sql_query);
	}
	else if ( $dbms == "postgres" )
	{
		echo "<br /><b>PLEASE REMOVE THE FIELD auth_download FROM THE TABLE phpbb_forums MANUALLY.</b><br />";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE phpbb_forums DROP
			CONSTRAINT [DF_phpbb_forums_auth_download],
			COLUMN auth_download;
		GO	";
		evaluate_statement($sql_query);
	}
}

if (row_in_shema(AUTH_ACCESS_TABLE, 'auth_download'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") || ($dbms == 'msaccess') )
	{
		$sql_query = "ALTER TABLE phpbb_auth_access DROP auth_download;";
		evaluate_statement($sql_query);
	}
	else if ( $dbms == "postgres" )
	{
		echo "<br /><b>PLEASE REMOVE THE FIELD auth_download FROM THE TABLE phpbb_auth_access MANUALLY.</b><br />";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE phpbb_auth_access DROP
			CONSTRAINT [DF_phpbb_auth_access_auth_download],
			COLUMN auth_download;
		GO	";
		evaluate_statement($sql_query);
	}
}

if (row_in_shema(POSTS_TABLE, 'post_attachment'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") || ($dbms == 'msaccess') )
	{
		$sql_query = "ALTER TABLE phpbb_posts DROP post_attachment;";
		evaluate_statement($sql_query);
	}
	else if ( $dbms == "postgres" )
	{
		echo "<br /><b>PLEASE REMOVE THE FIELD post_attachment FROM THE TABLE phpbb_posts MANUALLY.</b><br />";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE phpbb_posts DROP
			CONSTRAINT [DF_phpbb_posts_post_attachment],
			COLUMN post_attachment;
		GO	";
		evaluate_statement($sql_query);
	}
}

if (row_in_shema(TOPICS_TABLE, 'topic_attachment'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") || ($dbms == 'msaccess') )
	{
		$sql_query = "ALTER TABLE phpbb_topics DROP topic_attachment;";
		evaluate_statement($sql_query);
	}
	else if ( $dbms == "postgres" )
	{
		echo "<br /><b>PLEASE REMOVE THE FIELD topic_attachment FROM THE TABLE phpbb_topics MANUALLY.</b><br />";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE phpbb_topics DROP
			CONSTRAINT [DF_phpbb_topics_topic_attachment],
			COLUMN topic_attachment;
		GO	";
		evaluate_statement($sql_query);
	}
}

if (row_in_shema(PRIVMSGS_TABLE, 'privmsgs_attachment'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") || ($dbms == 'msaccess') )
	{
		$sql_query = "ALTER TABLE phpbb_privmsgs DROP privmsgs_attachment;";
		evaluate_statement($sql_query);
	}
	else if ( $dbms == "postgres" )
	{
		echo "<br /><b>PLEASE REMOVE THE FIELD privmsgs_attachment FROM THE TABLE phpbb_privmsgs MANUALLY.</b><br />";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE phpbb_privmsgs DROP
			CONSTRAINT [DF_phpbb_privmsgs_privmsgs_attachment],
			COLUMN privmsgs_attachment;
		GO	";
		evaluate_statement($sql_query);
	}
}

if ( $errored )
{
	$message = "<br />Some queries failed. Please contact me via email, pm, at the board or whatever, so we can solve your problems...<br />";
}
else
{
	$message = "<br />Attachment Mod Tables successfully deleted.";
}

echo "\n<br />\n<b>COMPLETE!</b><br />\n";
echo $message . "<br />";
echo "<br /><b>NOW DELETE THIS FILE</b><br />\n";
echo "</body>";
echo "</html>";

?>