Within this directory you will find all needed update and install/uninstall scripts.
All scripts here have to be copied to the phpBB2 Root Directory (if the Instructions says to run the file) 
and don't forget to delete them after execution.

Additional Scripts:

create_thumbnails.php:
If you want to create thumbnails from already existing Attachments this is the file you need. :)
Before you use this script, please make sure you have visited the Special Category Screen
in your Administration Panel to search for the imagick program and to make sure you have
enabled Thumbnail Creation and tested the Settings.
After you have done so, Upload the script to your phpBB2 Directory and execute it.
You have to choose whether to create thumbnails manually (You can choose the Attachment) or
to create the Thumnails automatically, without any action required from you.
If you choose the manual way and the Attachment where you clicked on (Create Thumbnail Link) 
does not disappear from the list, the Thumnail Creation does not worked for this Attachment.

revar_filenames.php:
This file is for renaming your files within your Upload Directory to the Real Filename.
(for example translates 1_28732432523.zip to attach_mod.zip)
Please run this file only once after upgrading from 2.2.4.

check_lang_files.php:
This is mainly for Attachment Mod Language Pack Authors, to determine differences
between the English Attachment Mod Language Files and their files.
This file will list missing Language Variables and not anymore needed Language Variables.

