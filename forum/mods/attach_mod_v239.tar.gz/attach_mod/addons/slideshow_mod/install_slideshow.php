<?php

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);	
include($phpbb_root_path.'includes/sql_parse.'.$phpEx);

header("Pragma: no-cache");                                    // HTTP/1.0
header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0", false); // HTTP/1.1
header("Expires: Sun, 18 May 1980 16:32:00 GMT");              // in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified

//
// Check DB Type
//
if ( (!isset($dbms)) || ($dbms == 'oracle') || ($dbms == 'msaccess') )
{
	message_die(GENERAL_MESSAGE, 'This Mod does not support Oracle or MSAccess.');
}

include($phpbb_root_path.'includes/db.'.$phpEx);

$attach_version = '';

$sql = "SELECT config_value FROM " . ATTACH_CONFIG_TABLE . " WHERE config_name = 'attach_version'";
$result = $db->sql_query($sql);

if ($result)
{
	if ($db->sql_numrows($result) > 0)
	{
		$row = $db->sql_fetchrow($result);
		$attach_version = trim($row['config_value']);
	}
}

if ($attach_version == '')
{
	$attach_version = ATTACH_VERSION;
	$attach_version = trim($attach_version);
}

$version_fields = array();
$version_fields = explode('.', $attach_version);

if ( (!strstr($attach_version, '2.3.')) )
{
	message_die(GENERAL_MESSAGE, 'Wrong Attachment Mod Version detected.<br />Please update your Attachment Mod (V' . $attach_version . ') to at least Version 2.3.7 before using this addon.');
}

$available_dbms = array(
	"mysql" => array(
		"SCHEMA" => "attach_mysql", 
		"DELIM" => ";",
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_remarks"
	), 
	"mysql4" => array(
		"SCHEMA" => "attach_mysql", 
		"DELIM" => ";", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_remarks"
	),
	"mssql" => array(
		"SCHEMA" => "attach_mssql", 
		"DELIM" => "GO", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	),
	"mssql-odbc" =>	array(
		"SCHEMA" => "attach_mssql", 
		"DELIM" => "GO",
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	),
	"postgres" => array(
		"LABEL" => "PostgreSQL 7.x",
		"SCHEMA" => "attach_postgres", 
		"DELIM" => ";", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	)
);

$dbms_schema = 'schemas/' . $available_dbms[$dbms]['SCHEMA'] . '_schema.sql';
$dbms_basic = 'schemas/' . $available_dbms[$dbms]['SCHEMA'] . '_basic.sql';

$remove_remarks = $available_dbms[$dbms]['COMMENTS'];;
$delimiter = $available_dbms[$dbms]['DELIM']; 
$delimiter_basic = $available_dbms[$dbms]['DELIM_BASIC']; 

$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);

// Check if a given row is present in table $table
function row_in_schema($table, $key)
{
	global $db, $table_prefix;

	$sql = "SELECT " . $key . " FROM " . $table;
	$sql = preg_replace('/phpbb_/', $table_prefix, $sql);

	$result = $db->sql_query($sql);

	if ($result)
	{
		return (TRUE);
	}
	else
	{
		return (FALSE);
	}
}

//
// Run a complete SQL-Statement, this can be a array
//
function evaluate_statement($sql_query, $hide = FALSE, $replace = FALSE)
{
	global $table_prefix, $remove_remarks, $delimiter, $db;
	
	$errored = FALSE;
	if ($replace)
	{
		$sql_query = preg_replace('/phpbb_/', $table_prefix, $sql_query);
	}

	$sql_query = $remove_remarks($sql_query);
	$sql_query = split_sql_file($sql_query, $delimiter);

	$sql_count = count($sql_query);

	for($i = 0; $i < $sql_count; $i++)
	{
		if (!$hide)
		{
			echo "Running :: " . $sql_query[$i];
		}
		flush();

		if ( !($result = $db->sql_query($sql_query[$i])) )
		{
			$errored = true;
			$error = $db->sql_error();
			if (!$hide)
			{
				echo " -> <b>FAILED</b> ---> <u>" . $error['message'] . "</u><br /><br />\n\n";
			}
		}
		else
		{
			if (!$hide)
			{
				echo " -> <b><span class=\"ok\">COMPLETED</span></b><br /><br />\n\n";
			}
		}
	}

	if ($errored)
	{
		return (FALSE);
	}
	else
	{
		return $result;
	}
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--

font,th,td,p,body { font-family: "Courier New", courier; font-size: 11pt }

a:link,a:active,a:visited { color : #006699; }
a:hover		{ text-decoration: underline; color : #DD6900;}

hr	{ height: 0px; border: solid #D1D7DC 0px; border-top-width: 1px;}

.maintitle,h1,h2	{font-weight: bold; font-size: 22px; font-family: "Trebuchet MS",Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000000;}

.ok {color:green}

/* Import the fancy styles for IE only (NS4.x doesn't use the @import function) */
@import url("templates/subSilver/formIE.css"); 
-->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#006699" vlink="#5584AA">

<table width="100%" border="0" cellspacing="0" cellpadding="10" align="center"> 
	<tr>
		<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td><img src="templates/subSilver/images/logo_phpBB.gif" border="0" alt="Forum Home" vspace="1" /></td>
				<td align="center" width="100%" valign="middle"><span class="maintitle">Installing Slideshow Mod</span></td>
			</tr>
		</table></td>
	</tr>
</table>

<br clear="all" />

<?php

if (!row_in_schema('phpbb_attachments_desc', 'width'))
{
	if (($dbms == 'mysql') || ($dbms == 'mysql4'))
	{
		$sql_query = '
		ALTER TABLE phpbb_attachments_desc
		ADD width SMALLINT(5) UNSIGNED DEFAULT \'0\' NOT NULL,
		ADD height SMALLINT(5) UNSIGNED DEFAULT \'0\' NOT NULL,
		ADD border TINYINT(1) DEFAULT \'0\' NOT NULL;
		';
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = '
		ALTER TABLE phpbb_attachments_desc ADD width int4;
		ALTER TABLE phpbb_attachments_desc ADD height int4;
		ALTER TABLE phpbb_attachments_desc ADD border int2;

		UPDATE phpbb_attachments_desc SET width = 0, height = 0, border = 0;
		ALTER TABLE phpbb_attachments_desc ALTER COLUMN width SET DEFAULT 0;
		ALTER TABLE phpbb_attachments_desc ALTER COLUMN height SET DEFAULT 0;
		ALTER TABLE phpbb_attachments_desc ALTER COLUMN border SET DEFAULT 0;
		';
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_attachments_desc] WITH NOCHECK ADD 
		[width] [int],
		[height] [int],
		[border] [int]
		GO	";
	}

	evaluate_statement($sql_query, FALSE, TRUE);
}

// Update existing image informations
$sql = "SELECT attach_id, physical_filename 
  	FROM " . ATTACHMENTS_DESC_TABLE . " 
	WHERE (width = 0) AND (LEFT(mimetype, 5) = 'image')";

if ( !($result = $db->sql_query($sql)) ) 
{ 
	echo 'error: ' . $sql; exit(); 
}

while ( $row = $db->sql_fetchrow($result) )
{
	$filename[] = trim($row['physical_filename']);
	$attach_id[] = intval($row['attach_id']);
}

for ($i = 0; $i < count($filename); $i++)
{
	$file = $upload_dir . '/' . $filename[$i];
	$size = image_getdimension($file);
	if ($size[0])
	{
		$sql = 'UPDATE ' . ATTACHMENTS_DESC_TABLE . ' 
		SET width = ' . $size[0] . ', height = ' . $size[1] . '
		WHERE attach_id = ' . $attach_id[$i];

		if ( !($result = $db->sql_query($sql)) ) 
		{ 
			echo 'error: ' . $sql; exit(); 
		}
	}
	else
	{
		echo '<br />could not get image size for <a target="_blank" href="download.' . $phpEx . '?id=' . $attach_id[$i] . '">id=' . $attach_id[$i] . '</a> (<a target="_blank" href="' . $file . '">' . $filename[$i] . '</a>)';
	}
}
echo '<br>COMPLETE! PLEASE DELETE THIS SCRIPT!';

?>