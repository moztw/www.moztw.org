Attachment Mod Feature Addons

Within this directory you will find Features originally made for the Attachment Mod but not
integrated into it because the Attachment Mod is Feature Frozen.

But if you want this particular feature within your Board, you are able to add it.
Addons follow the normal Mod Installation Steps.

Please read the install.txt within the Addon Folders.

- NOTE: slideshow.php changed from Attachment Mod Version 2.3.8 to 2.3.9, please overwrite your old one with the new one.