Foxmosa IM Stickers   v1.0

@MozTW x P.C.polliwog
CC: BY-NC-SA-3.0 

Following Foxmosa at
http://moztw.org/foxmosa
http://facebook.com/Foxmosa

You can also buy the stickers for Line
https://store.line.me/stickershop/product/1005599/